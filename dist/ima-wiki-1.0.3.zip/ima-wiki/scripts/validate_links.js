require('./validate').main();
